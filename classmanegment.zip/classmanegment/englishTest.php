<?php

require 'english.php'; 

use PHPUnit\Framework\TestCase;

class englishTest extends TestCase
{
    public function testenglishFunction() {
        $result = englishFunction('expected_value'); 
        $this->assertEquals('expected output', $result); 

        $result = englishFunction('unexpected_value'); 
        $this->assertEquals('unexpected output', $result); 
    }
}
?>