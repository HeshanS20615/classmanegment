<?php

require 'science.php';

use PHPUnit\Framework\TestCase;

class scienceTest extends TestCase
{
    public function testscienceFunction() {
        $result = scienceFunction('expected_value'); 
        $this->assertEquals('expected output', $result); 

        $result = scienceFunction('unexpected_value'); 
        $this->assertEquals('unexpected output', $result); 
    }
}
?>