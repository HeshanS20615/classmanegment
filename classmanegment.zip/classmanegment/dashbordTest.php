<?php

require 'dashbord.php';

use PHPUnit\Framework\TestCase;

class dashbordTest extends TestCase
{
    public function testdashbordFunction() {
        $result = dashbordFunction('expected_value'); 
        $this->assertEquals('expected output', $result); 

        $result = dashbordFunction('unexpected_value'); 
        $this->assertEquals('unexpected output', $result); 
    }
}
?>